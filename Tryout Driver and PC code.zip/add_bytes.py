import sys

#  read a file and try adding a value to each byte from it and then search if the "TUM" string is in the file

def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <file>")
        return 1

    try:
        with open(sys.argv[1], "rb") as file:
            buffer = bytearray(file.read())
    except IOError:
        print(f"Error: cannot open file {sys.argv[1]}")
        return 1

    adding = 1
    while True:
        modified_buffer = bytearray((byte + adding) % 256 for byte in buffer)

        if b"TUM" in modified_buffer:
            print("Found TUM in file")
            # save the output to a file
            with open("output.bin", "wb") as file:
                file.write(modified_buffer)
            break

        adding += 1

if __name__ == "__main__":
    main()