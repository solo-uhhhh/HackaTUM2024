import sys

def main():
    if len(sys.argv) != 3:
        print("Usage: python <file>.py <input file> <output file>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    with open(input_file, "rb") as f:
        data = f.read()

    for i in range(1, 31):
        modified_data = bytes([byte * i for byte in data])
        if b"TUM" in modified_data:
            print(f"Found 'TUM' with multiplier {i}")
            with open(output_file, "wb") as f:
                f.write(modified_data)
            break
    else:
        print("Did not find 'TUM' in any modified data")

if __name__ == "__main__":
    main()
