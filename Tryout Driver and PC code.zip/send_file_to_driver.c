#include <stdio.h>
// #include <stdlib.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
// #include <cstdint>
#include <sys/types.h>

#define DEVICE_FILE "/dev/amo"  // Replace with your device file
#define IOCTL_SEND_FILE 0x80086104  // Define this request code in the driver
#define AMO_IOCTL_SELECT_FRMW 0x80086102
#define IOCTL_20006101 0x20006101



typedef struct proc {
    char _unused[0xc4];
    int32_t p_pid; // 0xc4
} __attribute__((packed)) proc;

typedef struct thread {
    uint64_t _unused;
    struct proc *td_proc; // 8
} __attribute__((packed)) thread;

int send_file_to_driver() {
    int fd, file_fd;
    char *buffer;
    size_t file_size;
    ssize_t bytes_read;

    // // Open the file to send
    // file_fd = open(filename, O_RDONLY);
    // if (file_fd < 0) {
    //     perror("Failed to open the file");
    //     return -1;
    // }

    if (ioctl(fd, IOCTL_20006101) == 0) {
        printf("IOCTL 0x20006101 succeeded\n");
    } else {
        perror("IOCTL 0x20006101 failed");
    }

    // // Get the file size
    // file_size = lseek(file_fd, 0, SEEK_END);
    // lseek(file_fd, 0, SEEK_SET);

    // // Allocate buffer to hold the file data
    // buffer = malloc(file_size);
    // if (!buffer) {
    //     perror("Failed to allocate buffer");
    //     close(file_fd);
    //     return -1;
    // }

    // // Read the file into the buffer
    // bytes_read = read(file_fd, buffer, file_size);
    // if (bytes_read < 0) {
    //     perror("Failed to read the file");
    //     free(buffer);
    //     close(file_fd);
    //     return -1;
    // }
    // close(file_fd);

    // Open the device file
    fd = open(DEVICE_FILE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open device file");
        free(buffer);
        return -1;
    }

    // __uint64_t *data = malloc(sizeof(__uint64_t));
    __uint64_t data = 0;
    // thread *td = malloc(sizeof(thread));
    thread td;
    proc p;
    td.td_proc = &p;
    // td->td_proc = malloc(sizeof(struct proc));
    // td->td_proc->p_pid = 0;
    td.td_proc->p_pid = 0;
    // Send the file data to the driver using ioctl
    if (ioctl(fd, AMO_IOCTL_SELECT_FRMW, &data, 0, &td) < 0) {
        // print the data
        printf("data: %lx\n", data);
        perror("ioctl failed");
        close(fd);
        free(buffer);
        return -1;
    }

    printf("File sent successfully to the driver.\n");

    // Clean up
    close(fd);
    free(buffer);
    return 0;
}

int main(int argc, char *argv[]) {
    // if (argc != 2) {
        // fprintf(stderr, "Usage: %s <file_to_send>\n", argv[0]);
        // return EXIT_FAILURE;
    // }

    return send_file_to_driver();
}
