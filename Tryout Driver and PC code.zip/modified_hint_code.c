#include <stdint.h>
#include <sys/types.h>
#define AMO_IOCTL_TEST 0x20006101
#define AMO_IOCTL_UNLOCK 0x80086103
#define AMO_IOCTL_SELECT_FRMW 0x80086102
static int ioctl(struct cdev *dev_unused, unsigned long cmd, uint64_t * data, int fflag__unused, struct thread *td)
{
        int error = 0;

        switch (cmd) {
        case AMO_IOCTL_TEST:
                goto out;

        case AMO_IOCTL_UNLOCK:
        {
                struct amo_state *st;
                st = get_or_create(td->td_proc->p_pid);
              

                if (((uint64_t)data) != st->pw)
                {
                        error = EPERM;
                        goto unlock;
                }

                st->step = AMO_STEP_UNLOCKED;
                goto unlock;
        }

        case AMO_IOCTL_SELECT_FRMW:
        {
                struct amo_state *st;
                st = get_or_create(td->td_proc->p_pid);
                st->pw += PASSWORD;

                if (st->step == AMO_STEP_LOCKED)
                {
                        error = EPERM;
                        goto unlock;
                }

                st->step = AMO_STEP_LOCKED;

                if (((uint64_t)data) > 2)
                {
                        error = EINVAL;
                        goto unlock;
                }

                st->slct_frmw = (uint64_t)data;
                goto unlock;
        }

        default:
                error = EINVAL;
                goto out;
				}
unlock:
        mtx_unlock(&amo_state_mtx);
out:
        return (error);
}