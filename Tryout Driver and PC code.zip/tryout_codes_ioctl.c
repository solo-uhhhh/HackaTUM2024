#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <errno.h>

#define IOCTL_20006101 0x20006101
#define IOCTL_80086103 0x80086103
#define IOCTL_80086102 0x80086102
#define IOCTL_80086101 0x80086101
#define IOCTL_80086104 0x80086104
#define IOCTL_80086105 0x80086105

int main() {
    int fd = open("/dev/amo", O_RDWR);
    if (fd < 0) {
        perror("Failed to open device");
        return 1;
    }

    if (ioctl(fd, IOCTL_20006101) == 0) {
        printf("IOCTL 0x20006101 succeeded\n");
    } else {
        perror("IOCTL 0x20006101 failed");
    }
    // allocate the value on the stack
    unsigned long input = malloc(sizeof(unsigned long));
    if (ioctl(fd, IOCTL_80086101, &input) == 0) {
        printf("IOCTL 0x80086101 succeeded\n");
    } else {
        perror("IOCTL 0x80086101 failed");
    }

    if (ioctl(fd, IOCTL_80086103, &input) == 0) {
        printf("IOCTL 0x80086103 succeeded\n");
    } else {
        perror("IOCTL 0x80086103 failed");
    }

    unsigned long comparison = 0x7e004a1cad1de60;
    if (ioctl(fd, IOCTL_80086102, &comparison) == 0) {
        printf("IOCTL 0x80086102 succeeded (values match)\n");
    } else {
        perror("IOCTL 0x80086102 failed (values do not match)");
    }

    // Additional IOCTL calls with multiple arguments
    unsigned long arg1 = 0x12345678;
    unsigned long arg2 = 0x87654321;
    if (ioctl(fd, IOCTL_80086104, &arg1) == 0) {
        printf("IOCTL 0x80086104 succeeded with arg1: 0x%lx\n", arg1);
    } else {
        perror("IOCTL 0x80086104 failed with arg1");
    }

    if (ioctl(fd, IOCTL_80086105, &arg2) == 0) {
        printf("IOCTL 0x80086105 succeeded with arg2: 0x%lx\n", arg2);
    } else {
        perror("IOCTL 0x80086105 failed with arg2");
    }

    close(fd);
    return 0;
}
