def xor_decrypt(data, key):
    return bytes([b ^ key for b in data])

with open('data2.bin', 'rb') as f:
    data = f.read()

for key in range(256):
    decrypted = xor_decrypt(data, key)
    if b'TUM' in decrypted:
        print(f"Found flag with key {key}: {decrypted}")
